%Multiclass svm classifier
function res = mSvmClassifier(data, answer ,sim_seq)

sim_num = size(sim_seq, 2);
res = zeros(sim_num, 1);

answers = unique(answer);




for i = 1:sim_num
    tr_data = data(sim_seq(:,i), :);
    tr_ans = answer(sim_seq(:,i), :);
    
    ts_data = data(~sim_seq(:,i),:);
    ts_ans = answer(~sim_seq(:,i),:);
    
    
    mdl = fitcsvm(tr_data, tr_ans,'KernelFunction','rbf',...
    'Standardize',true,'ClassNames',{'2','1'});
    pre = mdl.predict(ts_data);
    
    temp = zeros(length(pre),1);
    for j=1:length(temp)
        temp(j,1)=pre{j,1};
    end
    pre = temp;
    
    tr_ans = num2str(tr_ans);
    ts_ans = num2str(ts_ans);
    acc = sum(pre == ts_ans) / size(ts_ans, 1);
    res(i,1) = acc;
end

end