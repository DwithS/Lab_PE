data_path = 'C:\PE\data';
seq_path = 'C:\PE\seq';
LOAD_SEQ = true;
SAVE_SEQ = false;


lists = dir(data_path);
n = length(lists);

testNum = 50;
portion = 0.2;


resultCell = cell(12,10);
%1���� ���ϸ�
%2���� ���
%3���� ǥ������
%4���� ������
%5knn
%6nb
%7dt

h = waitbar(0,'Please Wait...');


for k = 3:3
    file_name = strcat(data_path,"\",lists(k).name);
    resultCell(k-2,1) = {file_name};
    data = load(file_name);
    
    seq_file = strcat(seq_path,"\",lists(k).name,"_seq.mat");
    if (LOAD_SEQ==true && (exist(seq_file,'file')~=0))
        resultCell(k-2,4)= {load(seq_file) };
    else
        temp = SeqGen(testNum,size(data.X,1),portion);
        resultCell(k-2,4)= {temp};
        if (SAVE_SEQ==true)
            save(seq_file,'temp');
        end        
    end
    
    
    
    
    result = knnClassifier(data.X,data.Y,resultCell{k-2,4});
    resultA = strcat(num2str(mean(result(:,1))), "��", num2str(std(result(:,1))));
    resultCell(k-2,5) = {resultA};
    
    %result = nbClassifier(data.X_dis,data.Y,resultCell{k-2,4});
    %resultA = strcat(num2str(mean(result(:,1))), "��", num2str(std(result(:,1))));
    %resultCell(k-2,6) = {resultA};
    
    result = dtClassifier(data.X_dis,data.Y,resultCell{k-2,4});
    resultA = strcat(num2str(mean(result(:,1))), "��", num2str(std(result(:,1))));
    resultCell(k-2,7) = {resultA};
    
    
    
    waitbar(k-2/n-2); 
end


