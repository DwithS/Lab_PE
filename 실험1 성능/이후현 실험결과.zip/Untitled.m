for i = 1:size(resultCell,1)
   str = resultCell{i,1};
   data = resultCell{i,4};
   str = strrep(str, 'C:\PE\data\','');
   str = strrep(str, '.mat','');
   save_path = strcat('C:\PE\seq\',str,'_seq.mat');
   save(save_path,'data');
end